<?php
// Start sessionen for å få tilgang til session-variabler
session_start();

// Sjekk om brukeren er logget inn
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Hvis brukeren ikke er logget inn, omdiriger til index.html
    header("Location: index.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gratulerer</title>
    <link rel="stylesheet" href="styles.css"> <!-- Bruk samme stil som på verifikasjonssiden -->
    <style>
        /* Global stil */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #121212;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 600px;
            padding: 20px;
            background-color: #1e1e1e;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        h1 {
            color: #00bcd4;
            margin-bottom: 20px;
        }

        p {
            color: #ffffff;
            font-size: 1.2em;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #00bcd4;
            color: #121212;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1.1em;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0288a5;
        }

        /* Responsivitet */
        @media screen and (max-width: 768px) {
            .container {
                padding: 15px;
            }

            h1 {
                font-size: 1.8em;
            }

            p {
                font-size: 1em;
            }

            .btn {
                font-size: 1em;
                padding: 8px 16px;
            }
        }

        @media screen and (max-width: 480px) {
            h1 {
                font-size: 1.5em;
            }

            .btn {
                font-size: 0.9em;
                padding: 6px 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Gratulerer!</h1>
            <p>Du har fullført 2FA-verifiseringen med suksess. Velkommen til Kabelkongen!</p>
            <a href="nettside.php" class="btn">Gå til nettsiden</a>
        </div>
    </div>
</body>
</html>
