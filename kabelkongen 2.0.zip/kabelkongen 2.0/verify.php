<?php
session_start();
require 'db.php';

// Funksjon for å generere et tilfeldig CAPTCHA-spørsmål
function generate_captcha() {
    $num1 = rand(1, 10);
    $num2 = rand(1, 10);
    $operators = ['+', '-'];
    $operator = $operators[array_rand($operators)];
    
    switch ($operator) {
        case '+':
            $answer = $num1 + $num2;
            break;
        case '-':
            if ($num1 < $num2) {
                list($num1, $num2) = [$num2, $num1];
            }
            $answer = $num1 - $num2;
            break;
    }
    
    $_SESSION['captcha_question'] = "$num1 $operator $num2";
    $_SESSION['captcha_answer'] = $answer;
}

// Generer CAPTCHA ved første besøk eller etter en feil
if ($_SERVER['REQUEST_METHOD'] == 'GET' || isset($_GET['reset'])) {
    generate_captcha();
}

$error_messages = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code = trim($_POST['code'] ?? '');
    $captcha = trim($_POST['captcha'] ?? '');
    $tos = isset($_POST['tos']);
    $user_id = $_SESSION['user_id'] ?? null;

    if (!$user_id) {
        $error_messages[] = "Ugyldig sesjon. Vennligst logg inn igjen.";
    }

    if (empty($code)) {
        $error_messages[] = "Vennligst skriv inn 2FA-koden.";
    }
    if (empty($captcha)) {
        $error_messages[] = "Vennligst svar på CAPTCHA-spørsmålet.";
    }
    if (!$tos) {
        $error_messages[] = "Du må godta vilkårene for å fortsette.";
    }

    if (!empty($captcha) && isset($_SESSION['captcha_answer']) && intval($captcha) !== intval($_SESSION['captcha_answer'])) {
        $error_messages[] = "Feil CAPTCHA. Vennligst prøv igjen.";
    }

    if (empty($error_messages)) {
        $stmt = $conn->prepare("SELECT * FROM two_factor_codes WHERE user_id = ? AND code = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->bind_param("is", $user_id, $code);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            // Sett bruker som innlogget og omdiriger til gratulasjonssiden
            $_SESSION['loggedIn'] = true; // Punkt 4 implementert her
            unset($_SESSION['captcha_question'], $_SESSION['captcha_answer']); // Fjern CAPTCHA fra sesjonen
            header("Location: congratulations.php");
            exit();  // Sørg for at scriptet stopper her
        } else {
            $error_messages[] = "Feil 2FA-kode. Vennligst prøv igjen.";
            generate_captcha();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifiser 2FA - Kabelkongen AS</title>
    <style>
        /* Generell stil */
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #0c0c0c;
            color: #ffffff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            background-color: #1e1e1e;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.5);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            font-size: 24px;
            color: #00bcd4;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
            color: #ffffff;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: none;
            border-radius: 8px;
            background-color: #333333;
            color: #ffffff;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus, input[type="password"]:focus {
            border: 2px solid #00bcd4;
            outline: none;
        }

        .captcha-container {
            margin-bottom: 15px;
        }

        .captcha-question {
            margin-bottom: 5px;
            font-size: 16px;
            color: #ffffff;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .checkbox-container input[type="checkbox"] {
            margin-right: 10px;
            transform: scale(1.2);
        }

        .checkbox-container label {
            font-size: 14px;
            color: #ffffff;
        }

        .checkbox-container a {
            color: #00bcd4;
            text-decoration: none;
        }

        .checkbox-container a:hover {
            text-decoration: underline;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #00bcd4;
            border: none;
            border-radius: 8px;
            color: #121212;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color: #0288a5;
            transform: scale(1.05);
        }

        .error-message {
            background-color: #ff4444;
            color: #ffffff;
            padding: 10px;
            margin-top: 10px;
            border-radius: 8px;
            font-size: 14px;
            width: 100%;
            text-align: center;
        }

        .info-box {
            margin-top: 20px;
            background-color: #e0f7fa;
            color: #00796b;
            border: 1px solid #b2dfdb;
            border-radius: 8px;
            font-size: 14px;
            padding: 12px;
            text-align: center;
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bekreft 2FA-kode</h1>
        <form method="POST" action="verify.php">
            <!-- 2FA-koden -->
            <label for="code">Skriv inn 2FA-koden</label>
            <input type="text" name="code" id="code" placeholder="2FA-kode" required>

            <!-- CAPTCHA -->
            <div class="captcha-container">
                <div class="captcha-question"><?php echo htmlspecialchars($_SESSION['captcha_question']); ?> = ?</div>
                <input type="text" name="captcha" id="captcha" placeholder="Svar her" required>
            </div>

            <!-- Terms of Service -->
            <div class="checkbox-container">
                <input type="checkbox" name="tos" id="tos" required>
                <label for="tos">Jeg godtar <a href="terms.html" target="_blank">vilkårene</a></label>
            </div>

            <button type="submit">Bekreft</button>
        </form>

        <!-- Feilmelding -->
        <?php if (!empty($error_messages)): ?>
            <div class="error-message">
                <?php foreach ($error_messages as $error): ?>
                    <div><?php echo htmlspecialchars($error); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Info tekstboks nederst -->
        <div class="info-box">
            Husk å sjekke spam-folder hvis du ikke ser e-posten.
        </div>
    </div>
</body>
</html>
