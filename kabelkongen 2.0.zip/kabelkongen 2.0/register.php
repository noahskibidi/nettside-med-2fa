<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $email, $password);

    if ($stmt->execute()) {
        $message = "Bruker registrert! <a href='login.php'>Logg inn her</a>";
    } else {
        $message = "Feil ved registrering: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrer deg - Kabelkongen</title>
    <style>
        /* Global stil */
        body {
            background-color: #121212;
            color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 400px;
            background-color: #1e1e1e;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        h1 {
            text-align: center;
            color: #00bcd4;
        }

        label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            background-color: #333;
            color: #fff;
        }

        input:focus {
            outline: 2px solid #00bcd4;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #00bcd4;
            border: none;
            border-radius: 5px;
            color: #121212;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0288a5;
        }

        .link {
            text-align: center;
            margin-top: 10px;
        }

        .link a {
            color: #00bcd4;
            text-decoration: none;
        }

        .link a:hover {
            text-decoration: underline;
        }

        .message {
            background-color: #333;
            color: #fff;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
        }

        .message a {
            color: #00bcd4;
            text-decoration: none;
        }

        .message a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container" id="form-container">
        <h1>Registrer deg</h1>
        <form method="POST" action="register.php">
            <label>Email:</label>
            <input type="email" name="email" required><br>
            <label>Passord:</label>
            <input type="password" name="password" required><br>
            <button type="submit">Registrer</button>
        </form>

        <?php if (isset($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <div class="link">
            <a href="login.php">Allerede registrert? Logg inn her.</a>
        </div>
    </div>
</body>
</html>
