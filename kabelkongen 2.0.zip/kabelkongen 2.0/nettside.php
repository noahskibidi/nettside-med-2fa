<?php
// Start sesjon
session_start();

// Funksjon for å sette session-variabel
function setLoginStatus($status) {
    $_SESSION['loggedIn'] = $status;
}

// Funksjon for å sjekke om brukeren er logget inn
function checkLoginStatus() {
    if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
        // Hvis brukeren ikke er logget inn, omdiriger til index.html
        header("Location: index.html");
        exit();
    } else {
        echo "<script>console.log('Brukeren er logget inn, fortsetter...');</script>";
    }
}

// Funksjon for å logge ut brukeren (fjerne session)
function logoutUser() {
    // Fjern sesjonen
    session_unset();
    session_destroy();
    // Omdiriger til innloggingssiden
    header("Location: index.html");
    exit();
}

// Hvis brukeren klikker på logg ut, kalles logoutUser()
if (isset($_POST['logout'])) {
    logoutUser();
}

// Kall på funksjon for å sjekke innlogging når siden lastes
checkLoginStatus();
?>

<!DOCTYPE html>
<html lang="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kabelkongen AS</title>
    <link rel="stylesheet" href="nettside.css">
    <style>
        /* Stil for reklamebanner nederst */
        .sticky-ad {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            color: white;
            text-align: center;
            padding: 15px 0;
            font-size: 18px;
            font-weight: bold;
            z-index: 1000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: background-color 0.3s;
        }

        .sticky-ad a {
            color: white;
            text-decoration: none;
            display: block;
            width: 100%;
            height: 100%;
        }

        /* Farger for ulike reklamer */
        .komplett { background-color:rgb(203, 210, 0); }
        .nrk { background-color: #003B5C; }
        .vg { background-color: red; }
        .tinder { background-color: orange; }
        .finn { background-color: #009CDE; }

        body {
            padding-bottom: 50px; /* Plass til reklamen nederst */
        }

        .gif-container {
            text-align: center;
            margin-top: 20px;
        }

        .gif-container img {
            width: 40%;
            max-width: 300px;
        }

        /* Skjul bildet som popper opp */
        #popup-image {
            display: none;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 2000;
        }
    </style>
</head>
<body>

    <!-- Sticky reklamebanner nederst -->
    <div class="sticky-ad" id="adBanner">
        <a href="https://www.finn.no" target="_blank" class="finn">
            Er du på jakt etter noe nytt? Sjekk ut fantastiske tilbud på Finn.no!
        </a>
    </div>

    <header>
        <div class="logo">
            <h1>Kabelkongen AS</h1>
        </div>
        <nav>
            <ul>
                <li><a href="nettside.php">Hjem</a></li>
                <li><a href="produkter.html">Produkter</a></li>
                <li><a href="kontakt.html">Kontakt oss</a></li>
                <li><a href="om_oss.html">Om oss</a></li>
            </ul>
        </nav>

        <!-- Form for å logge ut -->
        <form method="POST" action="">
            <button type="submit" name="logout" class="logout-button">Logg ut</button>
        </form>
    </header>

    <main class="home">
        <section class="intro">
            <h2>Velkommen til Kabelkongen AS</h2>
            <p>Din pålitelige leverandør av kvalitetskabel og tekniske løsninger.</p>
        </section>

        <div class="gif-container">
            <img src="https://media.tenor.com/EFDwfjT2GuQAAAAM/spinning-cat.gif" alt="Spinnende katt GIF">
        </div>
    </main>

    <footer>
        <p>&copy; 2025 Kabelkongen AS - Alle rettigheter forbeholdt.</p>
    </footer>

    <script>
        // Array med reklame-data
        const ads = [
            { link: "https://www.komplett.no", text: "Er du på jakt etter noe nytt? Sjekk ut fantastiske tilbud på Komplett.no!", class: "komplett" },
            { link: "https://www.nrk.no", text: "Se de beste programmene på NRK!", class: "nrk" },
            { link: "https://www.vg.no", text: "Følg de siste nyhetene på VG!", class: "vg" },
            { link: "https://www.tinder.com", text: "Finn kjærligheten på Tinder!", class: "tinder" },
            { link: "https://www.finn.no", text: "Sjekk ut tilbudene på Finn.no!", class: "finn" }
        ];

        let currentAd = 0;

        function changeAd() {
            const adBanner = document.getElementById('adBanner');
            adBanner.innerHTML = `<a href="${ads[currentAd].link}" target="_blank" class="${ads[currentAd].class}">
                ${ads[currentAd].text}
            </a>`;
            currentAd = (currentAd + 1) % ads.length; // Bytt til neste annonse
        }

        // Bytt reklame hvert 5. sekund
        setInterval(changeAd, 5000);
    </script>

</body>
</html>
