<?php
session_start();
require 'db.php';
require 'vendor/autoload.php'; // SendGrid-autoloader

use SendGrid\Mail\Mail;

function send2FACode($email, $code) {
    $emailObject = new Mail();
    $emailObject->setFrom("t113studios@gmail.com", "Kabelkongen");
    $emailObject->setSubject("Din 2FA-kode");
    $emailObject->addTo($email);
    $emailObject->addContent("text/plain", "Din 2FA-kode er: $code");

    // Sett API-nøkkelen direkte her
    $sendgridApiKey = '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';
    $sendgrid = new \SendGrid($sendgridApiKey);

    try {
        $response = $sendgrid->send($emailObject);
        if ($response->statusCode() == 202) {
            return true;
        } else {
            // Hvis SendGrid returnerer en feilstatus
            echo "Feil ved sending av e-post. Statuskode: " . $response->statusCode();
            return false;
        }
    } catch (Exception $e) {
        echo 'Feil ved sending av e-post: ' . $e->getMessage();
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

            $stmt = $conn->prepare("INSERT INTO two_factor_codes (user_id, code) VALUES (?, ?)");
            $stmt->bind_param("is", $user['id'], $code);
            $stmt->execute();

            $_SESSION['user_id'] = $user['id'];

            if (send2FACode($email, $code)) {
                header("Location: verify.php");
                exit();
            } else {
                echo "Kunne ikke sende 2FA-kode.";
            }
        } else {
            echo "Feil passord.";
        }
    } else {
        echo "Bruker ikke funnet.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Logg inn - Kabelkongen</title>
    <style>
        /* Global stil */
        body {
            background-color: #121212;
            color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 400px;
            background-color: #1e1e1e;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        }

        h1 {
            text-align: center;
            color: #00bcd4;
        }

        label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: none;
            border-radius: 5px;
            background-color: #333;
            color: #fff;
        }

        input:focus {
            outline: 2px solid #00bcd4;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #00bcd4;
            border: none;
            border-radius: 5px;
            color: #121212;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0288a5;
        }

        .link {
            text-align: center;
            margin-top: 10px;
        }

        .link a {
            color: #00bcd4;
            text-decoration: none;
        }

        .link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container" id="form-container">
        <h1>Logg inn</h1>
        <form method="POST" action="login.php">
            <label>Email:</label>
            <input type="email" name="email" required><br>
            <label>Passord:</label>
            <input type="password" name="password" required><br>
            <button type="submit">Logg inn</button>
        </form>
        <div class="link">
            <a href="register.php">Har du ikke en konto? Registrer deg her</a>
        </div>
    </div>
</body>
</html>
