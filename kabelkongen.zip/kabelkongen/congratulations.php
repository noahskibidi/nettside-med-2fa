<!DOCTYPE html>
<html lang="no">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gratulerer</title>
    <link rel="stylesheet" href="styles.css"> <!-- Bruk samme stil som på verifikasjonssiden -->
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Gratulerer!</h1>
            <p>Du har fullført 2FA-verifiseringen med suksess. Velkommen til Kabelkongen!</p>
            <a href="nettside.html" class="btn">Gå til nettsiden</a> <!-- Legg til en lenke til brukerens dashboard eller startside -->
        </div>
    </div>
</body>
</html>
