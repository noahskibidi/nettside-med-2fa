<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "kabelkongen";

$conn = new mysqli('localhost', 'root', 'root', 'kabelkongen', 3306);


if ($conn->connect_error) {
    die("Tilkobling feilet: " . $conn->connect_error);
}
?>

